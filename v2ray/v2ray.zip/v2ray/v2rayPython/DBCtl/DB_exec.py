#!/usr/bin/python3
# -*- coding: UTF-8 -*-  
# ssTest - info.py
# 2019/3/5 16:38
# Author:Kencin <myzincx@gmail.com>
import pymysql
from Config import DB_config


class SSQuery(object):
    port_table_name = 'user'  # 用户表
    ip_table_name = 'ss_node'  # 节点表
    v2ray_table_name = 'v2ray_node'  # v2ray节点表
    db = pymysql.connect(DB_config.HOST, DB_config.Username, DB_config.Password, DB_config.Database_name)
    cursor = db.cursor()
    port = list()  # 端口列表
    ip = list()    # ip列表
    id = list()    # 用户id列表
    v2ray_cof = list()  # v2ray用户配置列表

    def __init__(self):
        pass

    # 获取ss节点Ip和端口 测试端口是否被封用
    def the_info(self):
        sql_port = "SELECT port FROM %s WHERE enable != 0" % self.port_table_name
        sql_ip = "SELECT ip FROM %s" % self.ip_table_name
        try:
            self.cursor.execute(sql_port)
            port = self.cursor.fetchall()
            for i in port:
                self.port.append(i[0])
            self.cursor.execute(sql_ip)
            ip = self.cursor.fetchall()
            for i in ip:
                self.ip.append(i[0])
            return self.port, self.ip
        except Exception as e:
            print(e)
            self.db.close()

    # 现有用户加入v2ray特征
    def add_v2ray_user(self, uuid, alterId, the_id):
        sql_update = "UPDATE %s SET uuid = '%s', alterId = %d WHERE id = %d" % (self.port_table_name, uuid, alterId,
                                                                                 the_id)
        print(sql_update)
        try:
            self.cursor.execute(sql_update)
            self.db.commit()
        except Exception as e:
            print(e)
            self.db.close()

    # 获取所有有效用户id
    def get_id(self):
        sql_get_id = "SELECT id FROM %s WHERE enable != 0" % self.port_table_name
        try:
            self.cursor.execute(sql_get_id)
            id = self.cursor.fetchall()
            for i in id:
                self.id.append(i)
            return self.id
        except Exception as e:
            print(e)
            self.db.close()

    # 获取v2ray用户配置
    def get_v2ray(self):
        sql_get_v2ray = "SELECT uuid, alterId FROM %s WHERE enable != 0" %self.port_table_name
        try:
            self.cursor.execute(sql_get_v2ray)
            the_all = self.cursor.fetchall()
            for i in the_all:
                self.v2ray_cof.append({'id': i[0], 'alterId': i[1]})
            return self.v2ray_cof
        except Exception as e:
            print(e)
            self.db.close()

    # 添加或修改v2ray节点信息
    def modify_v2ray_node(self, the_info):
        sql_is_exist = "SELECT id From %s WHERE ip = '%s'" %(self.v2ray_table_name, the_info.get('ip'))
        try:
            self.cursor.execute(sql_is_exist)
            if self.cursor.fetchone():
                print(1)
                sql_update = "UPDATE %s SET port = %d, net = '%s', type = '%s'WHERE ip = '%s'" \
                             %(self.v2ray_table_name, the_info.get('port'), the_info.get('net'), the_info.get('type'),
                               the_info.get('ip'))
                self.cursor.execute(sql_update)
                self.db.commit()
            else:
                sql_insert = "INSERT INTO %s (ip, port, net, type) VALUES ('%s', %d, '%s', '%s')" \
                % (self.v2ray_table_name, the_info.get('ip'), the_info.get('port'),
                   the_info.get('net'), the_info.get('type'))
                self.cursor.execute(sql_insert)
                self.db.commit()
        except Exception as e:
            print(e)
            self.db.close()

    # 制作链接必备参数
    def user_info(self, the_id):
        sql_user_info = "SELECT username, port, passwd, uuid, alterId, method FROM %s WHERE id =%d"\
                        % (self.port_table_name, int(the_id))
        try:
            self.cursor.execute(sql_user_info)
            the_user_info = self.cursor.fetchone()
            return the_user_info
        except Exception as e:
            print(e)
            self.db.close()

    def the_node_info(self):
        sql_ss_node = "SELECT name, ip FROM %s" % self.ip_table_name
        sql_v2ray_node = "SELECT ps, ip, port, net, type FROM %s" % self.v2ray_table_name
        try:
            self.cursor.execute(sql_ss_node)
            the_ss_info = self.cursor.fetchall()
            self.cursor.execute(sql_v2ray_node)
            the_v2ray_info = self.cursor.fetchall()
            return the_ss_info, the_v2ray_info
        except Exception as e:
            print(e)
            self.db.close()

    def add_user(self, user_info):
        placeholders = ', '.join(['%s'] * len(user_info))  # 插入数据个数
        columns = ', '.join(user_info.keys())  # 插入的关键字
        sql = "INSERT INTO %s ( %s ) VALUES ( %s )" % (self.port_table_name, columns, placeholders)
        datas = tuple(user_info.values())  # 插入的values
        try:
            self.cursor.execute(sql, datas)
            self.db.commit()
        except Exception as e:
            print(e)
            self.db.close()


class VPSQuery(object):
    vps_table_name = 'vps'
    db = pymysql.connect(DB_config.HOST, DB_config.vps_Username, DB_config.vps_Password, DB_config.vps_Database_name)
    cursor = db.cursor()
    vps = list()  # vps列表

    def __init__(self):
        pass

    def vps_info(self, the_group):
        sql_vps_info = "SELECT name, ip, username, password, port FROM %s WHERE the_group = %d"\
                        % (self.vps_table_name, int(the_group))
        try:
            self.cursor.execute(sql_vps_info)
            the_vps_info = self.cursor.fetchall()
            return the_vps_info
        except Exception as e:
            print(e)
            self.db.close()


if __name__ == '__main__':
    # ss = SSQuery()
    # a, b = ss.the_node_info()
    # print(b[2][2])
    # print(ss.port)
    # print(ss.ip)
    vps = VPSQuery()
    a = vps.vps_info(2)
    for i in a:
        print(i)
