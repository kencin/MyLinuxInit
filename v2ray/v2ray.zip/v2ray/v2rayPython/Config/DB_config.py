#!/usr/bin/python3
# -*- coding: UTF-8 -*-  
# ssquery - config.py
# 2019/2/19 14:42
# Author:Kencin <myzincx@gmail.com>

# 数据库配置文件

HOST = '114.115.210.24'
Database_name = 'ssrpanel'
Username = 'ssr'
Password = 'SW7vj!C^X*Z6re8Wyg73'

vps_Database_name = 'vpsinfo'
vps_Username = 'vps_info'
vps_Password = 'KUA3IP*WTQK7*86kH'