#!/usr/bin/python3
# -*- coding: UTF-8 -*-  
# ssTest - uploadV2rayConf.py
# 2019/3/10 13:48
# Author:Kencin <myzincx@gmail.com>
# 自动上传服务器v2ray配置到数据库

import json
import urllib.request
from DBCtl import DB_exec

config_path = '/etc/v2ray/config.json'

with open(config_path, 'r', encoding="UTF-8") as f:
    file = f.read()
    a = json.loads(file)


# 获取当前主机ip
def get_local_ip():
    my_ip = urllib.request.urlopen('http://api.ipify.org').read()
    local_ip = bytes.decode(my_ip)
    return local_ip


port = a.get('inbounds')[0].get('port')
net = a.get('inbounds')[0].get('streamSettings').get('network')
if net == 'kcp':
    the_type = a.get('inbounds')[0].get('streamSettings').get('kcpSettings').get('header').get('type')
else:
    the_type = None
ip = get_local_ip()
v = 2
the_info ={
    'port': port,
    'net': net,
    'type': the_type,
    'ip': ip
}
ss = DB_exec.SSQuery()
ss.modify_v2ray_node(the_info)