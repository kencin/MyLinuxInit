#!/usr/bin/python3
# -*- coding: UTF-8 -*-  
# ssTest - modifyV2rayConf.py
# 2019/3/9 16:43
# Author:Kencin <myzincx@gmail.com>

# 根据数据库内容修改v2ray的conf.json

import json
from DBCtl import DB_exec
import os

config_path = '/etc/v2ray/config.json'

with open(config_path, 'r', encoding="UTF-8") as f:
    file = f.read()
    a = json.loads(file)

ss = DB_exec.SSQuery()
v2ray_info = ss.get_v2ray()
a.get('inbounds')[0].get('settings').get('clients').clear()
for i in v2ray_info:
    a.get('inbounds')[0].get('settings').get('clients').append(i)

with open(config_path, 'w', encoding="UTF-8") as f:
    f.write(json.dumps(a))
os.chmod(config_path, 644)
os.system('service v2ray start')
