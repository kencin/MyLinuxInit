import pymysql
import json
import urllib.request
import socket

def get_local_ip():
    my_ip = urllib.request.urlopen('http://api.ipify.org').read()
    local_ip = bytes.decode(my_ip)
    return local_ip

def get_node_id():
    config_path = "/usr/local/shadowsocksr/usermysql.json"
    with open(config_path, 'r', encoding="UTF-8") as f:
        file = f.read()
        a = json.loads(file)
        db_ip = a.get('host')
        db_user = a.get('user')
        db_pwd = a.get('password')
        db_dbName = a.get('db')

    db = pymysql.connect(db_ip, db_user, db_pwd, db_dbName)
    cursor = db.cursor()
    local_ip = get_local_ip()
    sql_select_node_id = "SELECT id FROM ss_node WHERE ip = '%s'" % local_ip
    sql_select_max_id = "SELECT id FROM ss_node ORDER BY id DESC"
    

    try:
        cursor.execute(sql_select_node_id)
        node_id = cursor.fetchone()
        
        if node_id == None:
            print("The IP:%s's data not in database , trying insert....." % local_ip)
            cursor.execute(sql_select_max_id)
            max_id = cursor.fetchone()
            max_id = 1 + max_id[0]
            hostname = socket.gethostname()
            sql_insert_node = "INSERT INTO ss_node (id, ip, name) VALUES (%d, '%s','%s') " %(max_id, local_ip, hostname)
            cursor.execute(sql_insert_node)
            db.commit()
            with open(config_path, 'r', encoding="UTF-8") as f:
                file = f.read()
                a = json.loads(file)
            with open(config_path, 'w', encoding="UTF-8") as f:
                a['node_id'] = max_id
                f.write(json.dumps(a))
            return
        with open(config_path, 'r', encoding="UTF-8") as f:
            file = f.read()
            a = json.loads(file)
        with open(config_path, 'w', encoding="UTF-8") as f:
            a['node_id'] = node_id[0]
            f.write(json.dumps(a))
    except Exception as e:
        print(e)
        db.close()

if __name__ == '__main__':
    get_node_id()